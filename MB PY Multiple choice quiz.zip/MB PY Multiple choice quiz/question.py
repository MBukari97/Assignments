class Question:
 #   defining the different attributes that will be included in a question in the brackets
    def __init__(self, prompt, answer):
        self.prompt = prompt
        self.answer = answer
